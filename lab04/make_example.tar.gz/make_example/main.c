#include "diary.h"

int main(void) {
	memo();
	calendar();
	return 0;
}
