#include "diary.h"

void memo() {
	printf("function memo.\n");
}
