#include "diary.h"

void calendar() {
	printf("function calendar.\n");
}
