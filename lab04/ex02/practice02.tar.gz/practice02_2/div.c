int funcDiv(int a, int b) {
	// do something
}
