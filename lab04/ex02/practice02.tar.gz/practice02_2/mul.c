int funcMul(int a, int b) {
	// do something
}
