int funcAdd(int a, int b) {
	// do something
}
