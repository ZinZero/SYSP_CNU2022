#include <stdio.h>

void memo();
void calendar();
int funcAdd(int a, int b);
int funcSub(int a, int b);
int funcMul(int a, int b);
int funcDiv(int a, int b);
