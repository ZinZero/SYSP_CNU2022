#include <stdio.h>

void main(){

	printf("Hello I'm test2.c\n");
}
